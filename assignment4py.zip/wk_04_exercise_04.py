print("Question 4:")

numbers = []
number = 0


while number < 10:
  numbers.append(number**2)
  number = number + 1
print(numbers)
