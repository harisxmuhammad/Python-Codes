#1
#A variable refers to a a value, which could be recalled when necessary as well as changed.