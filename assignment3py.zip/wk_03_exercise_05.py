#5
line = ("the wheels on the bus go round and round round and round round and round the wheels on the bus go round and round all day long")

x = line[25:41]
rnd = "round and round"
y = rnd.split(line)

print(x, y)
