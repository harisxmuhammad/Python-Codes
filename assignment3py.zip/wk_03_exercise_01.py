#1
#A string is inmutable, which means its value cannot be changed, on the other hand, a list is mutable. A string contains only characters, but a list can contain both characters and integers. Interger and floats are both mutable. Floats contain decimals while integers do not. 

