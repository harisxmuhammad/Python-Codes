#3
#class = 120
#break = 15

#teaching_time = class - break
#print(teaching_time)
#syntax error
#Class and break are indentifiers used as reserved words and cannot be used as ordinary variables.
#to fix the issue, a _ should be inserted for variable class and break, for example, class_ = 120 and break_ = 15