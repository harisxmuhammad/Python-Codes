#hardware or software
#Webcam = "Webcam"
#WebbrowserDatabase = "software"
#Memory_stick = "hardware"
#database = "software"
#Holiday_pictures_stored_on_a_memory_stick = "software"

