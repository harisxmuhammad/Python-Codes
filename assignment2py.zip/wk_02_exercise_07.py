#7
#using meaningful variables can help relate with a specific value.
#downside of using long variables makes it harder to recall. Also, typos can happen if variables are long