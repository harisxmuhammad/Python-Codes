#8
#capacity = c
#numbers = car number
#c_1_car = 20
#c_2_car = 15
#c_3_car = 20
#c_4_car = 2 * 15
#c_5_car = 20 + c_4_car
#c_6_car = c_5_car

#train = c_1_car + c_2_car + c_3_car + c_4_car + c_5_car + c_6_car 

#print(train)
