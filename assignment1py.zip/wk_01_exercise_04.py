#code of output below
#print("do")
print("you")
print("think")
print("this")
print("is")
#print("not")
print("easy")
#print("?")