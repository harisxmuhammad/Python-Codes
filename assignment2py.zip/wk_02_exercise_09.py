#9
l_cm = 20*100
w_cm = 35*100
distance = 150
distance_2 = 200
room_size = l_cm*w_cm

table_l = 120
table_w = 120
table_size = table_l*table_w

l_students = (l_cm - distance)/(distance + table_l)
w_students = (w_cm - distance)/(distance + table_w)

total_students = int(l_students*w_students)

l_students_2 = (l_cm - distance_2)/(distance_2 + table_l)
w_students_2 = (w_cm - distance_2)/(distance_2 + table_w)

total_students_2 = int(l_students_2*w_students_2)


print(total_students, "students can fit in the room with", distance, "distance and", total_students_2, "with", distance_2)
