print("Question 7:")








playlist = ["Truth Hurts", "Don't stop me now", "Papauptai", "Valerie", "Malamente"]
  
#for song in range(len(playlist)-1):
    #next_song = playlist[song+1]
#print(next_song)
