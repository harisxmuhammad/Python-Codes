#6
name = 'Khadija'
age = '31'
profession = 'software developer'
role = 'project manager'
starting_date = 2014
current_date = 2021

years_in_job = current_date - starting_date
age_when_hired = int(age) - years_in_job 
print(name, "was", age_when_hired, "when she was hired.")