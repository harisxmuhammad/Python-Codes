#9
timetable = {
"language_processing_python": ["Monday at 12:30pm", "Friday at 8:30am "], 

"intro_R":["Wednesday at 8:30am"], 

"data mining": ["Tuesday at 3:15pm", "Thursday at 3:15pm"] , 

"clue": ["Monday at 3:15pm"] , 

"maths_ds": ["Friday at 10:15am"]
}



print(timetable["language_processing_python"])