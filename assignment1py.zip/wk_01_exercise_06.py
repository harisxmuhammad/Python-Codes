#differences between a computer program and a recipe
#Without an ingredient, a dish could still be made, however, for programming, you cannot mess up the syntax.
#computer programs are mixture of mathematics and language, on the other hand, recipes are purely human language
#the end result of a recipe is a tangible product, but for computer programs and codes, they are intangible.

