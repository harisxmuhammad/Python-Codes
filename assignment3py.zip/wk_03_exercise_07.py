#7 
e = ("this is a very simple sentence")
s = e.split()

etod = {"this": "dit", "is": "is", "a": "een", "very": "erg", "simple": "eenvoudige", "sentence": "zin"}
print(etod.values())
