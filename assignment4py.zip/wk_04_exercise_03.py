print("Question 3:")

#n = "2"
#while n != "8":
  #n = n*2
#print(n)
#it will keep multiplying with the string "2" as it never equals to 8. However, that could only happen if the strings are converted into integers, then the condition would meet.




















