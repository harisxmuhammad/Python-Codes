print("Question 8:")

f_sequence = [0, 1]

for i in range(2, 25):
  f_sequence.append(f_sequence[i-2]+f_sequence[i-1])
  
  
print(f_sequence)
  

  



