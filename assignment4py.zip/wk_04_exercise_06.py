print("Question 6:")
numbers = [2, 2, 5, 7, 11, 13, 17, 19, 23, 29]

#for number in numbers:
  #print(number)


food = ['milk', 'butter', 'cheese', 'yogurt', 'cream']
##for item in food:
  #print(item)


songs = ['satisfaction', 'angie', 'paint it black', 'gimme shelter', 'sympathy for the devil']

#for words in range(len(songs)):
  #print(songs[words])