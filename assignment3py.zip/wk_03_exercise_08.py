#8
monday = {"10:30": "psycholinguistics", "13:30":"", "15:30": "statistics in R"}

tuesday = {"13:30": "sociolinguistics", "15:30": "introduction to speech technology"}

wednesday = {"13:30": "programming for beginners python", "15:30": "introduction to language techonology"}

timetable = {"monday": monday, "tuesday": tuesday, "wednesday": wednesday}

print(timetable["monday"]["10:30"])