#subtraction
x = 20 - 8
print(x)