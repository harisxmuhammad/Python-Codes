print("Question 9:")

color = ["green", "blue", "black"]
animal = ["dog", "frog", "cow"]
c = []


for x in color:
  for j in animal:
    

    print(x, j)


