#6
str = "i don't like mondays"
s = str.replace("mondays", "sundays")
print(s)

#str ='i don"t like mondays' syntax error
#str[-7] = "sunday" > 'str' object does not support item assignment