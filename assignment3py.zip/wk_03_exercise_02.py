#2
#It will print 13, 3 times = 131313
#Will print 39
#will print 6.07.0
#Will print 13222
#Will print 666