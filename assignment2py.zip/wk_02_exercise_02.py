#2
#v = velocity
#mtr = meter
time_hr = 3
distance_km = 10

mins_in_3hr = time_hr*60
mtr_in_10km = 10*1000

velocity = int(distance_km/time_hr)
v_mtr_per_min = int(mtr_in_10km/mins_in_3hr)
km_in_mins = int(25*v_mtr_per_min)

print(velocity, v_mtr_per_min, km_in_mins,  sep = ",")