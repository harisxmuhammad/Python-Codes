#5
#name = 'Khadija'
#age = '31'
#profession = 'software developer'
#role = 'project manager'
#starting_date = 2014
#current_date = 2021

#years_in_job = current_date - starting_date
#age_when_hired = years_in_job - age
#print age_when_hired

#errors
#line 10 = Missing parentheses in call to 'print'
#line 9 = unsupported operand type(s) for -: 'int' and 'str'