print("Question 1:")

#Usually loops are handy for iteration, repititon and helps with shortening the code extensively.