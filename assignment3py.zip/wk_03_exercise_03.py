#3
#Sets cannot store unordered values and cannot hold duplicates meanwhile list can hold duplicates and can be ordered. When you have duplicate data, it is better to use a set over a list.