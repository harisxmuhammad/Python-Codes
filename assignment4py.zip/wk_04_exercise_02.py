print("Question 2:")

my_string = "La Villa Strangiato"
my_list =[]

for characters in my_string:
  x = my_list.append(characters)
print(my_list)

