c  = ["Black", "Orange", "Blue"]
a = ["Wolf", "Lion", "Whale"]
c_a = [c[0] +" "+ a[2], c[2] +" "+ a[0], c[1] +" "+ a[1]]
print(c_a)


